﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace MvcTaskManager.Identity
{
    public class ApplicationRole : IdentityRole<String>
    {
    }
}


